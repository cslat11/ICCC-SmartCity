# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render, get_object_or_404
from django.http import HttpResponse
from .models import Account
from django.template import loader
from django.http import Http404
from django.http import HttpResponseRedirect
from .forms import AccountForm
from django.template.context_processors import csrf
from django.shortcuts import render_to_response



# Create your views here.
def index(request):
    account = Account.objects.all()
    return render(request, 'login/index.html', {'account': account})


def detail(request, account_id):
    try:
        account = Account.objects.get(pk=account_id)
    except Account.DoesNotExist:
        raise Http404("User Does Not Exist")
    return render(request, 'login/Profile.html', {'account': account})


def adm(request):
    all_accounts = Account.objects.all()
    html = ''
    for acc in all_accounts:
        url = '/home/' + str(acc.id) + '/'
        html += ' <a href="' + url + '">' + acc.First_Name + ' ' + acc.Last_Name + '</a><br>'
    return HttpResponse(html)

def create(request):
    if request.POST:
        form = AccountForm(request.POST)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect('/login/')
    else:
        form = AccountForm()
       
        args = {}
        args.update(csrf(request))
        args['form'] = form
        return render_to_response('login/create.html', args)

def info(request, account_id):
    try:
        account = Account.objects.get(pk=account_id)
    except Account.DoesNotExist:
        raise Http404("User Does Not Exist")
    return render(request, 'login/infopage.html', {'account': account})

def detail2(request, account_id):
    if account_id:
        a = Account.objects.get(id=account_id)
        count = a.First_Name
        count += 1
        a.First_Name = count
        a.save()
        return HttpResponseRedirect('/login/create/%s' % account_id)
		
def edit(request, account_id):
	try:
		account = Account.objects.get(pk=account_id)
	except Account.DoesNotExist:
		raise Http404("User Does Not EXist")
	return render(request, 'login/Edit.html', {'account': account})


