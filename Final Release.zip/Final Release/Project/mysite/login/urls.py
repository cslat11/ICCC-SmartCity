﻿from django.conf.urls import include, url
from . import views
from .models import Account

urlpatterns = [
    #/Login/
    url(r'^$', views.index, name='index'),
    #/Login/Admin
    url(r'^admin$', views.adm, name='adm'),
    #detail
    url(r'^(?P<account_id>[0-9]+)/$', views.detail, name='detail'),
    #new thing
    #url(r'^login/new/(?P<account_id>\d+)/$', views.detail2, name='detail2'),
    #form
    url(r'^create$', views.create, name='create'),
    #info
    url(r'^(?P<account_id>[0-9]+)/info/$', views.info, name='info'),
    #login1
    #url(r'^?uname=(?P<account_id2>)/$', views.detail2, name='detail2'),
	#Edit
	url(r'^(?P<account_id>[0-9]+)/edit/$', views.edit, name='edit'),
]