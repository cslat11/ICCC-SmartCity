# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.db import models

# Create your models here.
class Account(models.Model):
    First_Name = models.CharField(max_length=15)
    Last_Name = models.CharField(max_length=15)
    Age = models.CharField(max_length=3)
    Sex = models.CharField(max_length=15)
    Occupation = models.CharField(max_length=15)
    email = models.CharField(max_length=15)
    Password = models.CharField(max_length=15)

    def __unicode__(self):
        return self.First_Name + ' - ' + self.Last_Name

class Password(models.Model):
    account = models.ForeignKey(Account, on_delete=models.CASCADE)
    Password = models.CharField(max_length=10)